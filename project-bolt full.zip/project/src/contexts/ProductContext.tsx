import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  stock: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
}

interface ProductContextType {
  products: Product[];
  addProduct: (product: Omit<Product, 'id'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  getProductById: (id: string) => Product | undefined;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const useProducts = () => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};

const initialProducts: Product[] = [
  {
    id: '1',
    name: 'Wireless Bluetooth Headphones',
    description: 'High-quality wireless headphones with noise cancellation and premium sound quality.',
    price: 199.99,
    stock: 15,
    category: 'Electronics',
    image: 'https://images.pexels.com/photos/3394650/pexels-photo-3394650.jpeg',
    rating: 4.5,
    reviews: 128
  },
  {
    id: '2',
    name: 'Smartphone Case',
    description: 'Durable protective case for smartphones with shock absorption and premium materials.',
    price: 29.99,
    stock: 50,
    category: 'Electronics',
    image: 'https://images.pexels.com/photos/1275229/pexels-photo-1275229.jpeg',
    rating: 4.2,
    reviews: 89
  },
  {
    id: '3',
    name: 'Coffee Mug Set',
    description: 'Set of 4 ceramic coffee mugs perfect for daily use with elegant design.',
    price: 39.99,
    stock: 25,
    category: 'Home & Kitchen',
    image: 'https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg',
    rating: 4.7,
    reviews: 156
  },
  {
    id: '4',
    name: 'Running Shoes',
    description: 'Comfortable running shoes with advanced cushioning and breathable material.',
    price: 129.99,
    stock: 8,
    category: 'Sports',
    image: 'https://images.pexels.com/photos/1464625/pexels-photo-1464625.jpeg',
    rating: 4.6,
    reviews: 203
  },
  {
    id: '5',
    name: 'Laptop Backpack',
    description: 'Professional laptop backpack with multiple compartments and water resistance.',
    price: 79.99,
    stock: 20,
    category: 'Accessories',
    image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg',
    rating: 4.4,
    reviews: 92
  },
  {
    id: '6',
    name: 'Desk Lamp',
    description: 'Modern LED desk lamp with adjustable brightness and USB charging port.',
    price: 59.99,
    stock: 12,
    category: 'Home & Office',
    image: 'https://images.pexels.com/photos/1329299/pexels-photo-1329299.jpeg',
    rating: 4.3,
    reviews: 67
  }
];

interface ProductProviderProps {
  children: ReactNode;
}

export const ProductProvider: React.FC<ProductProviderProps> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const storedProducts = localStorage.getItem('products');
    if (storedProducts) {
      setProducts(JSON.parse(storedProducts));
    } else {
      setProducts(initialProducts);
      localStorage.setItem('products', JSON.stringify(initialProducts));
    }
  }, []);

  useEffect(() => {
    if (products.length > 0) {
      localStorage.setItem('products', JSON.stringify(products));
    }
  }, [products]);

  const addProduct = (product: Omit<Product, 'id'>) => {
    const newProduct: Product = {
      ...product,
      id: Date.now().toString(),
    };
    setProducts(prev => [...prev, newProduct]);
  };

  const updateProduct = (id: string, updatedProduct: Partial<Product>) => {
    setProducts(prev =>
      prev.map(product =>
        product.id === id ? { ...product, ...updatedProduct } : product
      )
    );
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(product => product.id !== id));
  };

  const getProductById = (id: string): Product | undefined => {
    return products.find(product => product.id === id);
  };

  return (
    <ProductContext.Provider value={{
      products,
      addProduct,
      updateProduct,
      deleteProduct,
      getProductById
    }}>
      {children}
    </ProductContext.Provider>
  );
};